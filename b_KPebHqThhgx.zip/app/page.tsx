"use client";

import { useState } from "react";
import LoginScreen from "@/components/chat/LoginScreen";
import ChatApp from "@/components/chat/ChatApp";

export default function Page() {
  const [session, setSession] = useState<{
    username: string;
    channel: string;
  } | null>(null);

  if (!session) {
    return (
      <LoginScreen
        onJoin={(username, channel) => setSession({ username, channel })}
      />
    );
  }

  return (
    <ChatApp
      initialUsername={session.username}
      initialChannel={session.channel}
    />
  );
}

import { createClient } from "@/lib/supabase/server";
import { NextRequest, NextResponse } from "next/server";

// GET /api/messages/channel?channel=general&limit=50
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const channel = searchParams.get("channel");
  const limit = parseInt(searchParams.get("limit") || "100", 10);

  if (!channel) {
    return NextResponse.json({ error: "Channel required" }, { status: 400 });
  }

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("chat_messages")
    .select("*")
    .eq("channel", channel)
    .order("created_at", { ascending: true })
    .limit(limit);

  if (error) {
    console.error("[API] Error fetching channel messages:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ messages: data });
}

// POST /api/messages/channel
export async function POST(request: NextRequest) {
  const body = await request.json();
  const { channel, username, content } = body;

  if (!channel || !username || !content) {
    return NextResponse.json(
      { error: "channel, username, and content are required" },
      { status: 400 }
    );
  }

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("chat_messages")
    .insert({ channel, username, content })
    .select()
    .single();

  if (error) {
    console.error("[API] Error saving channel message:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ message: data });
}

import { createClient } from "@/lib/supabase/server";
import { NextRequest, NextResponse } from "next/server";

// GET /api/messages/private?user1=alice&user2=bob&limit=50
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const user1 = searchParams.get("user1");
  const user2 = searchParams.get("user2");
  const limit = parseInt(searchParams.get("limit") || "100", 10);

  if (!user1 || !user2) {
    return NextResponse.json(
      { error: "user1 and user2 required" },
      { status: 400 }
    );
  }

  const supabase = await createClient();
  
  // Get messages where either user is sender/recipient
  const { data, error } = await supabase
    .from("private_messages")
    .select("*")
    .or(
      `and(sender.eq.${user1},recipient.eq.${user2}),and(sender.eq.${user2},recipient.eq.${user1})`
    )
    .order("created_at", { ascending: true })
    .limit(limit);

  if (error) {
    console.error("[API] Error fetching private messages:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ messages: data });
}

// POST /api/messages/private
export async function POST(request: NextRequest) {
  const body = await request.json();
  const { sender, recipient, content } = body;

  if (!sender || !recipient || !content) {
    return NextResponse.json(
      { error: "sender, recipient, and content are required" },
      { status: 400 }
    );
  }

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("private_messages")
    .insert({ sender, recipient, content })
    .select()
    .single();

  if (error) {
    console.error("[API] Error saving private message:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ message: data });
}

"use client";

import { UserStatus } from "@/hooks/use-mqtt-chat";

interface SidebarProps {
  username: string;
  currentChannel: string;
  channels: string[];
  onlineUsers: UserStatus[];
  onSwitchChannel: (channel: string) => void;
  onOpenPrivate: (recipient: string) => void;
  connected: boolean;
  reconnecting: boolean;
}

export default function Sidebar({
  username,
  currentChannel,
  channels,
  onlineUsers,
  onSwitchChannel,
  onOpenPrivate,
  connected,
  reconnecting,
}: SidebarProps) {
  const usersInChannel = onlineUsers.filter(
    (u) => u.channel === currentChannel && u.username !== username
  );
  const otherUsers = onlineUsers.filter(
    (u) => u.channel !== currentChannel && u.username !== username
  );

  return (
    <aside className="flex h-full w-60 shrink-0 flex-col bg-[var(--chat-sidebar-bg)] border-r border-border">
      {/* Server / App Header */}
      <div className="flex h-14 items-center justify-between border-b border-border px-4">
        <span className="text-sm font-semibold text-foreground">
          MQTT Chat
        </span>
        {/* Connection badge */}
        <div className="flex items-center gap-1.5">
          <span
            className={`h-2 w-2 rounded-full ${
              connected
                ? "bg-[var(--chat-online)]"
                : reconnecting
                ? "animate-pulse bg-yellow-400"
                : "bg-muted-foreground"
            }`}
          />
          <span className="text-[10px] text-muted-foreground">
            {connected ? "Connecté" : reconnecting ? "Reconnexion…" : "Hors ligne"}
          </span>
        </div>
      </div>

      {/* Channels */}
      <div className="flex flex-col gap-0.5 p-3">
        <p className="mb-1 px-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Salons
        </p>
        {channels.map((ch) => (
          <button
            key={ch}
            onClick={() => onSwitchChannel(ch)}
            className={`flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors ${
              ch === currentChannel
                ? "bg-accent text-foreground font-medium"
                : "text-muted-foreground hover:bg-accent/50 hover:text-foreground"
            }`}
          >
            <span className="text-muted-foreground">#</span>
            <span className="truncate">{ch}</span>
          </button>
        ))}
      </div>

      <div className="mx-3 border-t border-border" />

      {/* Users in channel */}
      <div className="flex flex-col gap-0.5 overflow-y-auto p-3">
        <p className="mb-1 px-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          Dans ce salon — {usersInChannel.length + 1}
        </p>

        {/* Self */}
        <div className="flex items-center gap-2 rounded-md px-2 py-1.5">
          <UserAvatar username={username} online />
          <span className="truncate text-sm font-medium text-foreground">
            {username}
            <span className="ml-1 text-[10px] text-muted-foreground">(vous)</span>
          </span>
        </div>

        {usersInChannel.map((u) => (
          <button
            key={u.username}
            onClick={() => onOpenPrivate(u.username)}
            title={`Message privé à ${u.username}`}
            className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-accent/50 hover:text-foreground"
          >
            <UserAvatar username={u.username} online={u.online} />
            <span className="truncate">{u.username}</span>
          </button>
        ))}

        {/* Users in other channels */}
        {otherUsers.length > 0 && (
          <>
            <p className="mb-1 mt-3 px-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              Autres salons — {otherUsers.length}
            </p>
            {otherUsers.map((u) => (
              <button
                key={u.username}
                onClick={() => onOpenPrivate(u.username)}
                title={`Message privé à ${u.username}`}
                className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-accent/50 hover:text-foreground"
              >
                <UserAvatar username={u.username} online={u.online} />
                <span className="truncate">{u.username}</span>
                <span className="ml-auto text-[10px] opacity-60">
                  #{u.channel}
                </span>
              </button>
            ))}
          </>
        )}
      </div>

      {/* Self footer */}
      <div className="mt-auto flex items-center gap-2 border-t border-border bg-[var(--chat-sidebar-section)] px-3 py-2.5">
        <UserAvatar username={username} online={connected} size="sm" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-foreground">
            {username}
          </p>
          <p className="truncate text-[10px] text-muted-foreground">
            #{currentChannel}
          </p>
        </div>
      </div>
    </aside>
  );
}

// ── Avatar helper ─────────────────────────────────────────────────────────────
function UserAvatar({
  username,
  online,
  size = "md",
}: {
  username: string;
  online: boolean;
  size?: "sm" | "md";
}) {
  const initial = username.charAt(0).toUpperCase();
  const hue = username
    .split("")
    .reduce((acc, c) => acc + c.charCodeAt(0), 0) % 360;

  const dim = size === "sm" ? "h-6 w-6 text-[10px]" : "h-7 w-7 text-xs";

  return (
    <div className="relative shrink-0">
      <div
        className={`${dim} flex items-center justify-center rounded-full font-semibold text-white`}
        style={{ backgroundColor: `hsl(${hue}, 60%, 45%)` }}
        aria-hidden="true"
      >
        {initial}
      </div>
      <span
        className={`absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-[var(--chat-sidebar-bg)] ${
          online ? "bg-[var(--chat-online)]" : "bg-muted-foreground"
        }`}
      />
    </div>
  );
}

"use client";

import { ChatMessage } from "@/hooks/use-mqtt-chat";
import MessageList from "./MessageList";
import MessageInput from "./MessageInput";

interface PrivateMessageModalProps {
  username: string;
  recipient: string;
  messages: ChatMessage[];
  onSend: (content: string) => void;
  onTyping: () => void;
  onClose: () => void;
}

export default function PrivateMessageModal({
  username,
  recipient,
  messages,
  onSend,
  onTyping,
  onClose,
}: PrivateMessageModalProps) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-end bg-background/60 backdrop-blur-sm p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="flex h-[500px] w-80 flex-col overflow-hidden rounded-xl border border-border bg-card shadow-2xl">
        {/* Header */}
        <div className="flex items-center gap-3 border-b border-border px-4 py-3">
          <div
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-semibold text-white"
            style={{
              backgroundColor: `hsl(${
                recipient.split("").reduce((a, c) => a + c.charCodeAt(0), 0) % 360
              }, 60%, 45%)`,
            }}
            aria-hidden="true"
          >
            {recipient.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="truncate text-sm font-medium text-foreground">
              {recipient}
            </p>
            <p className="text-[10px] text-muted-foreground">
              Message privé · QoS 2
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Fermer"
            className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
          >
            <svg
              className="h-4 w-4"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M6 18 18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        {/* Messages */}
        <div className="flex flex-1 flex-col overflow-hidden">
          <MessageList
            messages={messages}
            currentChannel="private"
            username={username}
            privateWith={recipient}
          />
        </div>

        {/* Input */}
        <MessageInput
          onSend={onSend}
          onTyping={onTyping}
          placeholder={`Message privé à ${recipient}…`}
        />
      </div>
    </div>
  );
}

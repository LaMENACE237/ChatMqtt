"use client";

import { useEffect, useRef } from "react";
import { ChatMessage } from "@/hooks/use-mqtt-chat";

interface MessageListProps {
  messages: ChatMessage[];
  currentChannel: string;
  username: string;
  privateWith?: string | null;
}

export default function MessageList({
  messages,
  currentChannel,
  username,
  privateWith,
}: MessageListProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  // For private messages, we receive the filtered conversation directly
  // For channel messages, filter by channel
  const filtered = privateWith
    ? messages // Already filtered by ChatApp
    : messages.filter(
        (m) => !m.isPrivate && m.channel === currentChannel
      );

  // Group consecutive messages from the same author
  type Group = { author: string; msgs: ChatMessage[] };
  const groups: Group[] = [];
  for (const msg of filtered) {
    const last = groups[groups.length - 1];
    if (last && last.author === msg.username) {
      last.msgs.push(msg);
    } else {
      groups.push({ author: msg.username, msgs: [msg] });
    }
  }

  if (groups.length === 0) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-2 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-accent">
          <svg
            className="h-6 w-6 text-muted-foreground"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={1.5}
            aria-hidden="true"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.184-4.183a1.14 1.14 0 0 1 .778-.332 48.294 48.294 0 0 0 5.83-.498c1.585-.233 2.708-1.626 2.708-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z"
            />
          </svg>
        </div>
        <p className="text-sm font-medium text-foreground">
          {privateWith
            ? `Début de votre conversation privée avec ${privateWith}`
            : `Début du salon #${currentChannel}`}
        </p>
        <p className="text-xs text-muted-foreground">
          Soyez le premier à écrire quelque chose !
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-1 flex-col gap-0 overflow-y-auto px-4 py-4">
      {groups.map((group, gi) => {
        const isSelf = group.author === username;
        const hue = group.author
          .split("")
          .reduce((acc, c) => acc + c.charCodeAt(0), 0) % 360;
        const initial = group.author.charAt(0).toUpperCase();

        return (
          <div key={gi} className="group flex items-start gap-3 px-1 py-1 rounded-lg hover:bg-accent/30 transition-colors">
            {/* Avatar */}
            <div
              className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-semibold text-white"
              style={{ backgroundColor: `hsl(${hue}, 60%, 45%)` }}
              aria-hidden="true"
            >
              {initial}
            </div>

            <div className="min-w-0 flex-1">
              {/* Author + timestamp */}
              <div className="flex items-baseline gap-2">
                <span
                  className={`text-sm font-semibold ${
                    isSelf ? "text-primary" : "text-foreground"
                  }`}
                >
                  {group.author}
                </span>
                <span className="text-[10px] text-muted-foreground">
                  {formatTime(group.msgs[0].timestamp)}
                </span>
              </div>

              {/* Messages */}
              {group.msgs.map((msg) => (
                <p
                  key={msg.id}
                  className="mt-0.5 text-sm leading-relaxed text-foreground/90 break-words"
                >
                  {msg.content}
                </p>
              ))}
            </div>
          </div>
        );
      })}
      <div ref={bottomRef} />
    </div>
  );
}

function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

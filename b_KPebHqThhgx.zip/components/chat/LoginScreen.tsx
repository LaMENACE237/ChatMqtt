"use client";

import { useState } from "react";

const DEFAULT_CHANNELS = ["général", "dev", "random", "annonces"];

interface LoginScreenProps {
  onJoin: (username: string, channel: string) => void;
}

export default function LoginScreen({ onJoin }: LoginScreenProps) {
  const [username, setUsername] = useState("");
  const [channel, setChannel] = useState("général");
  const [customChannel, setCustomChannel] = useState("");
  const [useCustom, setUseCustom] = useState(false);
  const [error, setError] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const u = username.trim();
    const c = (useCustom ? customChannel : channel).trim();
    if (!u) return setError("Veuillez entrer un pseudo.");
    if (!c) return setError("Veuillez choisir un salon.");
    if (u.length < 2 || u.length > 20)
      return setError("Le pseudo doit contenir entre 2 et 20 caractères.");
    if (!/^[a-zA-Z0-9_\-àâéèêëîïôùûüç ]+$/.test(u))
      return setError("Pseudo invalide — lettres, chiffres et _ - uniquement.");
    setError("");
    onJoin(u, c);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-md">
        {/* Logo / Header */}
        <div className="mb-10 text-center">
          <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 ring-1 ring-primary/30">
            <svg
              className="h-8 w-8 text-primary"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={1.8}
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M8.625 9.75a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375m-13.5 3.01c0 1.6 1.123 2.994 2.707 3.227 1.087.16 2.185.283 3.293.369V21l4.184-4.183a1.14 1.14 0 0 1 .778-.332 48.294 48.294 0 0 0 5.83-.498c1.585-.233 2.708-1.626 2.708-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0 0 12 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018Z"
              />
            </svg>
          </div>
          <h1 className="text-2xl font-semibold text-foreground">
            MQTT Chat
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Projet ISEN 2026 — Communication distribuée via MQTT
          </p>
        </div>

        {/* Card */}
        <div className="rounded-xl border border-border bg-card p-8 shadow-lg">
          <h2 className="mb-6 text-base font-medium text-foreground">
            Rejoindre le chat
          </h2>

          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            {/* Username */}
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="username"
                className="text-sm font-medium text-foreground/80"
              >
                Pseudo
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="ex: alice42"
                autoComplete="off"
                maxLength={20}
                className="rounded-lg border border-border bg-input px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-colors"
              />
            </div>

            {/* Channel */}
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium text-foreground/80">
                Salon
              </label>
              {!useCustom ? (
                <div className="grid grid-cols-2 gap-2">
                  {DEFAULT_CHANNELS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setChannel(c)}
                      className={`rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
                        channel === c
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border bg-secondary text-muted-foreground hover:border-primary/50 hover:text-foreground"
                      }`}
                    >
                      # {c}
                    </button>
                  ))}
                </div>
              ) : (
                <input
                  type="text"
                  value={customChannel}
                  onChange={(e) => setCustomChannel(e.target.value)}
                  placeholder="nom-du-salon"
                  maxLength={30}
                  className="rounded-lg border border-border bg-input px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-colors"
                />
              )}
              <button
                type="button"
                onClick={() => setUseCustom(!useCustom)}
                className="mt-1 self-start text-xs text-primary hover:underline"
              >
                {useCustom ? "Choisir un salon existant" : "Salon personnalisé..."}
              </button>
            </div>

            {/* Error */}
            {error && (
              <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive-foreground">
                {error}
              </p>
            )}

            {/* Submit */}
            <button
              type="submit"
              className="mt-1 w-full rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90 active:opacity-75"
            >
              Rejoindre
            </button>
          </form>
        </div>

        {/* Footer info */}
        <p className="mt-4 text-center text-xs text-muted-foreground">
          Broker: <span className="font-mono text-foreground/60">broker.emqx.io:8084</span> via WebSocket TLS
        </p>
      </div>
    </div>
  );
}

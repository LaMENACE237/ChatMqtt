"use client";

import { useState, useCallback, useEffect } from "react";
import { useMqttChat } from "@/hooks/use-mqtt-chat";
import Sidebar from "./Sidebar";
import MessageList from "./MessageList";
import MessageInput from "./MessageInput";
import PrivateMessageModal from "./PrivateMessageModal";

const DEFAULT_CHANNELS = ["général", "dev", "random", "annonces"];

interface ChatAppProps {
  initialUsername: string;
  initialChannel: string;
}

export default function ChatApp({
  initialUsername,
  initialChannel,
}: ChatAppProps) {
  const [currentChannel, setCurrentChannel] = useState(initialChannel);
  const [channels, setChannels] = useState<string[]>(() => {
    const base = [...DEFAULT_CHANNELS];
    if (!base.includes(initialChannel)) base.push(initialChannel);
    return base;
  });
  const [privateRecipient, setPrivateRecipient] = useState<string | null>(null);

  const {
    connectionState,
    messages,
    privateConversations,
    onlineUsers,
    typingUsers,
    historyLoaded,
    sendMessage,
    sendPrivateMessage,
    sendTyping,
    switchChannel,
    loadPrivateHistory,
  } = useMqttChat(initialUsername, currentChannel);

  // Keep channel list in sync when other users mention new channels
  useEffect(() => {
    const seen = new Set(channels);
    messages.forEach((m) => {
      if (!m.isPrivate && m.channel && !seen.has(m.channel)) {
        seen.add(m.channel);
        setChannels((prev) => [...prev, m.channel]);
      }
    });
  }, [messages, channels]);

  const handleSwitchChannel = useCallback(
    (ch: string) => {
      if (ch === currentChannel) return;
      setCurrentChannel(ch);
      switchChannel(ch);
    },
    [currentChannel, switchChannel]
  );

  const handleSend = useCallback(
    (content: string) => {
      sendMessage(content, currentChannel);
    },
    [sendMessage, currentChannel]
  );

  const handleTyping = useCallback(() => {
    sendTyping(currentChannel);
  }, [sendTyping, currentChannel]);

  const handleOpenPrivate = useCallback(
    async (recipient: string) => {
      // Load history for this conversation
      await loadPrivateHistory(recipient);
      setPrivateRecipient(recipient);
    },
    [loadPrivateHistory]
  );

  const handlePrivateSend = useCallback(
    (content: string) => {
      if (!privateRecipient) return;
      sendPrivateMessage(content, privateRecipient);
    },
    [sendPrivateMessage, privateRecipient]
  );

  const typingText =
    typingUsers.length > 0
      ? typingUsers.length === 1
        ? `${typingUsers[0]} est en train d&apos;ecrire...`
        : `${typingUsers.join(", ")} ecrivent...`
      : null;

  const privateMessages = privateRecipient
    ? privateConversations[privateRecipient] || []
    : [];

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <Sidebar
        username={initialUsername}
        currentChannel={currentChannel}
        channels={channels}
        onlineUsers={onlineUsers}
        onSwitchChannel={handleSwitchChannel}
        onOpenPrivate={handleOpenPrivate}
        connected={connectionState.connected}
        reconnecting={connectionState.reconnecting}
      />

      {/* Main chat area */}
      <main className="flex flex-1 flex-col overflow-hidden bg-[var(--chat-message-bg)]">
        {/* Channel header */}
        <div className="flex h-14 shrink-0 items-center gap-3 border-b border-border px-5">
          <span className="text-lg font-semibold text-muted-foreground">#</span>
          <h1 className="text-base font-semibold text-foreground text-balance">
            {currentChannel}
          </h1>
          <div className="ml-auto flex items-center gap-3 text-xs text-muted-foreground">
            {connectionState.error && (
              <span className="text-destructive-foreground">
                {connectionState.error}
              </span>
            )}
            {!historyLoaded && (
              <span className="animate-pulse">Chargement historique...</span>
            )}
            <span>
              {onlineUsers.filter((u) => u.channel === currentChannel).length +
                1}{" "}
              en ligne
            </span>
            {/* QoS indicator */}
            <span className="hidden rounded border border-border bg-secondary px-1.5 py-0.5 font-mono text-[10px] sm:inline">
              QoS 1 - Retained - LWT
            </span>
          </div>
        </div>

        {/* Messages */}
        <div className="flex flex-1 flex-col overflow-hidden">
          <MessageList
            messages={messages}
            currentChannel={currentChannel}
            username={initialUsername}
          />
        </div>

        {/* Typing indicator */}
        <div className="h-5 px-5 text-xs italic text-muted-foreground">
          {typingText ?? ""}
        </div>

        {/* Input */}
        <MessageInput
          onSend={handleSend}
          onTyping={handleTyping}
          placeholder={`Message dans #${currentChannel}`}
          disabled={!connectionState.connected}
        />
      </main>

      {/* Private message modal */}
      {privateRecipient && (
        <PrivateMessageModal
          username={initialUsername}
          recipient={privateRecipient}
          messages={privateMessages}
          onSend={handlePrivateSend}
          onTyping={handleTyping}
          onClose={() => setPrivateRecipient(null)}
        />
      )}
    </div>
  );
}

"use client";

import { useEffect, useRef, useCallback, useState } from "react";
import mqtt, { MqttClient } from "mqtt";

// ─── Topic helpers ────────────────────────────────────────────────────────────
const GROUP = "isen-2026-group1";

export const topics = {
  /** QoS 1 — channel messages (at-least-once, important not to miss) */
  channelMessages: (channel: string) =>
    `${GROUP}/chat/channels/${channel}/messages`,
  /** QoS 0 — typing indicator (fire-and-forget, ephemeral) */
  channelTyping: (channel: string) =>
    `${GROUP}/chat/channels/${channel}/typing`,
  /** QoS 1, retained — user online status (also used as LWT target) */
  userStatus: (username: string) => `${GROUP}/chat/users/${username}/status`,
  /** QoS 2 — private messages (exactly-once delivery) */
  private: (from: string, to: string) => {
    const sorted = [from, to].sort();
    return `${GROUP}/chat/private/${sorted[0]}/${sorted[1]}`;
  },
};

// ─── Types ────────────────────────────────────────────────────────────────────
export type QoS = 0 | 1 | 2;

export interface ChatMessage {
  id: string;
  username: string;
  content: string;
  channel: string;
  timestamp: number;
  isPrivate?: boolean;
  recipient?: string;
}

export interface UserStatus {
  username: string;
  online: boolean;
  channel: string;
  lastSeen?: number;
}

export interface ConnectionState {
  connected: boolean;
  reconnecting: boolean;
  error: string | null;
}

export interface PrivateConversation {
  recipientUsername: string;
  messages: ChatMessage[];
  unreadCount: number;
}

// ─── Hook ─────────────────────────────────────────────────────────────────────
export function useMqttChat(
  username: string | null,
  currentChannel: string | null
) {
  const clientRef = useRef<MqttClient | null>(null);
  const [connectionState, setConnectionState] = useState<ConnectionState>({
    connected: false,
    reconnecting: false,
    error: null,
  });
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [privateConversations, setPrivateConversations] = useState<
    Record<string, ChatMessage[]>
  >({});
  const [onlineUsers, setOnlineUsers] = useState<UserStatus[]>([]);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const [historyLoaded, setHistoryLoaded] = useState(false);
  const typingTimerRef = useRef<Record<string, ReturnType<typeof setTimeout>>>(
    {}
  );

  // ── Load channel history from Supabase ───────────────────────────────────
  const loadChannelHistory = useCallback(async (channel: string) => {
    try {
      const res = await fetch(
        `/api/messages/channel?channel=${encodeURIComponent(channel)}&limit=100`
      );
      if (!res.ok) throw new Error("Failed to load history");
      const data = await res.json();
      const historyMessages: ChatMessage[] = (data.messages || []).map(
        (m: { id: string; username: string; content: string; channel: string; created_at: string }) => ({
          id: m.id,
          username: m.username,
          content: m.content,
          channel: m.channel,
          timestamp: new Date(m.created_at).getTime(),
        })
      );
      setMessages((prev) => {
        // Merge history with existing messages, avoiding duplicates
        const existingIds = new Set(prev.map((p) => p.id));
        const newMessages = historyMessages.filter(
          (m) => !existingIds.has(m.id)
        );
        return [...newMessages, ...prev].sort(
          (a, b) => a.timestamp - b.timestamp
        );
      });
      setHistoryLoaded(true);
    } catch (err) {
      console.error("[MQTT] Failed to load channel history:", err);
    }
  }, []);

  // ── Load private message history ─────────────────────────────────────────
  const loadPrivateHistory = useCallback(
    async (otherUser: string) => {
      if (!username) return;
      try {
        const res = await fetch(
          `/api/messages/private?user1=${encodeURIComponent(username)}&user2=${encodeURIComponent(otherUser)}&limit=100`
        );
        if (!res.ok) throw new Error("Failed to load private history");
        const data = await res.json();
        const historyMessages: ChatMessage[] = (data.messages || []).map(
          (m: { id: string; sender: string; recipient: string; content: string; created_at: string }) => ({
            id: m.id,
            username: m.sender,
            content: m.content,
            channel: "private",
            timestamp: new Date(m.created_at).getTime(),
            isPrivate: true,
            recipient: m.recipient,
          })
        );
        setPrivateConversations((prev) => ({
          ...prev,
          [otherUser]: historyMessages.sort(
            (a, b) => a.timestamp - b.timestamp
          ),
        }));
        return historyMessages;
      } catch (err) {
        console.error("[MQTT] Failed to load private history:", err);
        return [];
      }
    },
    [username]
  );

  // ── Save message to DB ───────────────────────────────────────────────────
  const saveChannelMessage = useCallback(
    async (channel: string, content: string) => {
      if (!username) return;
      try {
        await fetch("/api/messages/channel", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ channel, username, content }),
        });
      } catch (err) {
        console.error("[MQTT] Failed to save message:", err);
      }
    },
    [username]
  );

  const savePrivateMessage = useCallback(
    async (recipient: string, content: string) => {
      if (!username) return;
      try {
        await fetch("/api/messages/private", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sender: username, recipient, content }),
        });
      } catch (err) {
        console.error("[MQTT] Failed to save private message:", err);
      }
    },
    [username]
  );

  // ── Connect ─────────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!username || !currentChannel) return;

    // Load history first
    loadChannelHistory(currentChannel);

    // Last Will Testament — QoS 1, retained
    const lwt = {
      topic: topics.userStatus(username),
      payload: JSON.stringify({
        username,
        online: false,
        channel: currentChannel,
        lastSeen: Date.now(),
      }),
      qos: 1 as QoS,
      retain: true,
    };

    const brokerUrl = "wss://broker.hivemq.com:8884/mqtt";
    const client = mqtt.connect(brokerUrl, {
      clientId: `isen-${username}-${Math.random().toString(16).slice(2, 8)}`,
      clean: false,
      will: lwt,
      reconnectPeriod: 5000,
      connectTimeout: 30000,
      keepalive: 60,
    });

    clientRef.current = client;

    client.on("connect", () => {
      console.log("[MQTT] Connected successfully!");
      setConnectionState({ connected: true, reconnecting: false, error: null });

      // Subscribe to current channel messages — QoS 1
      client.subscribe(topics.channelMessages(currentChannel), { qos: 1 });
      // Subscribe to typing — QoS 0
      client.subscribe(topics.channelTyping(currentChannel), { qos: 0 });
      // Subscribe to user status updates — QoS 1
      client.subscribe(`${GROUP}/chat/users/+/status`, { qos: 1 });
      // Subscribe to private messages for this user — QoS 2
      client.subscribe(`${GROUP}/chat/private/${username}/+`, { qos: 2 });
      client.subscribe(`${GROUP}/chat/private/+/${username}`, { qos: 2 });

      // Announce presence — QoS 1, retained
      client.publish(
        topics.userStatus(username),
        JSON.stringify({
          username,
          online: true,
          channel: currentChannel,
          lastSeen: Date.now(),
        }),
        { qos: 1, retain: true }
      );
    });

    client.on("reconnect", () => {
      console.log("[MQTT] Reconnecting...");
      setConnectionState((s) => ({ ...s, reconnecting: true, error: null }));
    });

    client.on("error", (err) => {
      console.error("[MQTT] Error:", err.message);
      setConnectionState((s) => ({ ...s, error: err.message }));
    });

    client.on("offline", () => {
      console.log("[MQTT] Client offline");
      setConnectionState((s) => ({
        ...s,
        connected: false,
        reconnecting: true,
      }));
    });

    client.on("message", (topic, payloadBuffer) => {
      let payload: unknown;
      try {
        payload = JSON.parse(payloadBuffer.toString());
      } catch {
        return;
      }

      // ── Channel messages ───────────────────────────────────────────────────
      const chanMsgMatch = topic.match(
        /^isen-2026-group1\/chat\/channels\/(.+)\/messages$/
      );
      if (chanMsgMatch) {
        const msg = payload as ChatMessage;
        setMessages((prev) => {
          if (prev.find((m) => m.id === msg.id)) return prev;
          return [...prev, { ...msg, channel: chanMsgMatch[1] }].sort(
            (a, b) => a.timestamp - b.timestamp
          );
        });
        return;
      }

      // ── Typing ─────────────────────────────────────────────────────────────
      const typingMatch = topic.match(
        /^isen-2026-group1\/chat\/channels\/(.+)\/typing$/
      );
      if (typingMatch) {
        const { username: typingUser } = payload as { username: string };
        if (typingUser === username) return;
        setTypingUsers((prev) =>
          prev.includes(typingUser) ? prev : [...prev, typingUser]
        );
        clearTimeout(typingTimerRef.current[typingUser]);
        typingTimerRef.current[typingUser] = setTimeout(() => {
          setTypingUsers((prev) => prev.filter((u) => u !== typingUser));
        }, 3000);
        return;
      }

      // ── User status (online / LWT offline) ────────────────────────────────
      const statusMatch = topic.match(
        /^isen-2026-group1\/chat\/users\/(.+)\/status$/
      );
      if (statusMatch) {
        const status = payload as UserStatus;
        setOnlineUsers((prev) => {
          const without = prev.filter((u) => u.username !== status.username);
          return status.online ? [...without, status] : without;
        });
        return;
      }

      // ── Private messages ───────────────────────────────────────────────────
      const privMatch = topic.match(
        /^isen-2026-group1\/chat\/private\/(.+)\/(.+)$/
      );
      if (privMatch) {
        const msg = payload as ChatMessage;
        const otherUser =
          msg.username === username ? msg.recipient! : msg.username;
        setPrivateConversations((prev) => {
          const existing = prev[otherUser] || [];
          if (existing.find((m) => m.id === msg.id)) return prev;
          return {
            ...prev,
            [otherUser]: [...existing, { ...msg, isPrivate: true }].sort(
              (a, b) => a.timestamp - b.timestamp
            ),
          };
        });
      }
    });

    return () => {
      if (client.connected) {
        client.publish(
          topics.userStatus(username),
          JSON.stringify({
            username,
            online: false,
            channel: currentChannel,
            lastSeen: Date.now(),
          }),
          { qos: 1, retain: true }
        );
      }
      client.end();
      clientRef.current = null;
    };
  }, [username, currentChannel, loadChannelHistory]);

  // ── Send channel message (QoS 1) ─────────────────────────────────────────
  const sendMessage = useCallback(
    async (content: string, channel: string) => {
      if (!clientRef.current?.connected || !username) return;
      const msg: ChatMessage = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        username,
        content,
        channel,
        timestamp: Date.now(),
      };
      // Publish to MQTT
      clientRef.current.publish(
        topics.channelMessages(channel),
        JSON.stringify(msg),
        { qos: 1 }
      );
      // Save to DB for history
      await saveChannelMessage(channel, content);
    },
    [username, saveChannelMessage]
  );

  // ── Send private message (QoS 2 — exactly-once) ──────────────────────────
  const sendPrivateMessage = useCallback(
    async (content: string, recipient: string) => {
      if (!clientRef.current?.connected || !username) return;
      const msg: ChatMessage = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        username,
        content,
        channel: "private",
        timestamp: Date.now(),
        isPrivate: true,
        recipient,
      };
      // Publish to MQTT — QoS 2 for exactly-once
      clientRef.current.publish(
        topics.private(username, recipient),
        JSON.stringify(msg),
        { qos: 2 }
      );
      // Add to local state
      setPrivateConversations((prev) => ({
        ...prev,
        [recipient]: [...(prev[recipient] || []), msg].sort(
          (a, b) => a.timestamp - b.timestamp
        ),
      }));
      // Save to DB for history
      await savePrivateMessage(recipient, content);
    },
    [username, savePrivateMessage]
  );

  // ── Send typing indicator (QoS 0) ─────────────────────────────────────────
  const sendTyping = useCallback(
    (channel: string) => {
      if (!clientRef.current?.connected || !username) return;
      clientRef.current.publish(
        topics.channelTyping(channel),
        JSON.stringify({ username }),
        { qos: 0 }
      );
    },
    [username]
  );

  // ── Switch channel ─────────────────────────────────────────────────────────
  const switchChannel = useCallback(
    (newChannel: string) => {
      if (!clientRef.current || !username) return;
      const client = clientRef.current;

      // Unsubscribe old channel
      if (currentChannel) {
        client.unsubscribe(topics.channelMessages(currentChannel));
        client.unsubscribe(topics.channelTyping(currentChannel));
      }

      // Subscribe to new channel
      client.subscribe(topics.channelMessages(newChannel), { qos: 1 });
      client.subscribe(topics.channelTyping(newChannel), { qos: 0 });

      // Update presence
      if (client.connected) {
        client.publish(
          topics.userStatus(username),
          JSON.stringify({
            username,
            online: true,
            channel: newChannel,
            lastSeen: Date.now(),
          }),
          { qos: 1, retain: true }
        );
      }

      // Load history for new channel
      setHistoryLoaded(false);
      loadChannelHistory(newChannel);
    },
    [username, currentChannel, loadChannelHistory]
  );

  // Filter messages for current channel
  const channelMessages = messages.filter(
    (m) => m.channel === currentChannel && !m.isPrivate
  );

  return {
    connectionState,
    messages: channelMessages,
    allMessages: messages,
    privateConversations,
    onlineUsers,
    typingUsers,
    historyLoaded,
    sendMessage,
    sendPrivateMessage,
    sendTyping,
    switchChannel,
    loadPrivateHistory,
  };
}

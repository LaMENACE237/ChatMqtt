-- Chat messages table (for channel messages)
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  channel TEXT NOT NULL,
  username TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Private messages table
CREATE TABLE IF NOT EXISTS public.private_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender TEXT NOT NULL,
  recipient TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for faster queries
CREATE INDEX IF NOT EXISTS idx_chat_messages_channel ON public.chat_messages(channel);
CREATE INDEX IF NOT EXISTS idx_chat_messages_created_at ON public.chat_messages(created_at);
CREATE INDEX IF NOT EXISTS idx_private_messages_users ON public.private_messages(sender, recipient);
CREATE INDEX IF NOT EXISTS idx_private_messages_created_at ON public.private_messages(created_at);

-- Enable RLS but allow all operations (public chat, no auth required)
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.private_messages ENABLE ROW LEVEL SECURITY;

-- Policies for public access (anyone can read/write)
DROP POLICY IF EXISTS "Allow all read on chat_messages" ON public.chat_messages;
CREATE POLICY "Allow all read on chat_messages" ON public.chat_messages FOR SELECT USING (true);

DROP POLICY IF EXISTS "Allow all insert on chat_messages" ON public.chat_messages;
CREATE POLICY "Allow all insert on chat_messages" ON public.chat_messages FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "Allow all read on private_messages" ON public.private_messages;
CREATE POLICY "Allow all read on private_messages" ON public.private_messages FOR SELECT USING (true);

DROP POLICY IF EXISTS "Allow all insert on private_messages" ON public.private_messages;
CREATE POLICY "Allow all insert on private_messages" ON public.private_messages FOR INSERT WITH CHECK (true);
